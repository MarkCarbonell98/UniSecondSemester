1) Files *.ipynb enthalten den Quellcode aus den Vorlesungen. IPYNB ist der Standardformat vom Jupyter Notebook. Damit lassen sie sich öffnen, bearbeiten und ausführen. Alternative kann man die Files z.B. mittel online App

https://htmtopdf.herokuapp.com/ipynbviewer/

ins HTML/PDF Format umwandeln.

2) Das Ausführen vom Python Code kann mit

http://www.pythontutor.com/visualize.html#mode=edit

App illustriert werden.
